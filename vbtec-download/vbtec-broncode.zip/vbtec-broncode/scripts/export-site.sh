#!/usr/bin/env bash
# Builds the website for upload: makes website-online.zip in the project folder.
# The export needs a few temporary changes (see prepare-static-export.sh); they are
# undone automatically afterwards, so your own files stay exactly as they were.
# Usage: npm run export
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
BAK="$(mktemp -d)"
FILES="src/proxy.ts src/app/robots.ts src/app/sitemap.ts src/app/opengraph-image.tsx"
for f in $FILES; do [ -f "$f" ] && mkdir -p "$BAK/$(dirname "$f")" && cp "$f" "$BAK/$f"; done
restore() { for f in $FILES; do [ -f "$BAK/$f" ] && cp "$BAK/$f" "$f"; done; rm -rf "$BAK"; }
trap restore EXIT
echo "Bezig met opbouwen van de website (dit duurt 1 à 3 minuten)..."
sh scripts/prepare-static-export.sh
rm -rf out
STATIC_EXPORT=1 NEXT_PUBLIC_BASE_PATH="" npx next build
rm -f website-online.zip
(cd out && zip -qr "$ROOT/website-online.zip" .)
echo ""
echo "Klaar: website-online.zip staat in $ROOT"
echo "Upload de inhoud van die zip naar de hoofdmap van je hosting."
