# Website VB-TEC

De website van VB-TEC (www.vbtec.be), gebouwd in Next.js.

## Eenmalig installeren

1. Installeer **Node.js** (de LTS-versie) via https://nodejs.org.
2. Open een terminal in deze map en voer uit:

```bash
npm install
```

## Lokaal bekijken terwijl je aanpast

```bash
npm run dev
```

Open http://localhost:3000. Elke wijziging die je bewaart, zie je meteen in de browser.

## De site klaarmaken om te uploaden

```bash
npm run export
```

Dit maakt `website-online.zip` in deze map. Upload de inhoud van die zip naar de hoofdmap van de hosting (en vervang de oude bestanden).

## Waar staat wat?

| Wat | Waar |
|---|---|
| Bedrijfsgegevens (telefoon, e-mail, adres, BTW, openingsuren) en het menu | `src/content/site.ts` |
| Teksten van de dienstpagina's (zonnepanelen, thuisbatterij, ...) | `src/content/services.ts` |
| Kennisbankartikels | `src/content/kennisbank.ts` |
| Blogartikels | `src/content/blog.ts` |
| Vergelijkingen | `src/content/comparisons.ts` |
| Vragen en antwoorden (FAQ) | `src/content/faqs.ts` |
| Over ons, hoe we werken | `src/content/company-pages.ts` |
| Cijfers en tarieven (prijzen, premies, aantallen) | `src/content/facts.ts` |
| Homepage: dagklok en offerteformulier | `src/components/dagklok/sections/` |
| Homepage: productstrook | `src/components/products/ProductsSection.tsx` |
| Homepage: blok "Alles over VB-TEC" | `src/components/dagklok/HomeMore.tsx` |
| Homepage: besparingscalculator | `src/components/dagklok/Calculator.tsx` |
| Bedrijvenpagina's en vacature | `src/components/dagklok/pages/` (titels en omschrijvingen: `src/content/dagklok-pages.ts`) |
| Projectfoto's (galerij) | `public/images/projecten/` |
| Foto's van de dienstpagina's en andere pagina's | `public/images/` (overzicht met omschrijvingen: `src/content/images.ts`) |
| Foto's van de homepage en bedrijvenpagina's | `public/dagklok/img/` |
| Logo's | `public/brand/` |
| Privacyverklaring | `src/app/privacy/page.tsx` |

## Afbeeldingen

- Formaat: `.webp` of `.jpg`, ongeveer 2000 px breed, liefst kleiner dan 300 KB.
- Een foto vervangen: geef de nieuwe foto altijd een **nieuwe bestandsnaam** (bv. `zonnepanelen-dak-2.webp`) en pas de verwijzing aan. Met dezelfde naam kunnen browsers en de hosting nog de oude foto uit hun cache tonen.
- Een nieuwe foto toevoegen: zet hem in de juiste map en verwijs ernaar vanuit de pagina of het content-bestand, met een korte omschrijving (alt-tekst) van wat erop staat.
