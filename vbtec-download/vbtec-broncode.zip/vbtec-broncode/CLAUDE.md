# Website VB-TEC: werkafspraken

Dit is de website van VB-TEC (Next.js 16, App Router, TypeScript, CSS Modules). De persoon die je helpt is de marketeer van VB-TEC, geen ontwikkelaar. Leg uit in eenvoudig Nederlands en doe het technische werk zelf.

## Werkwijze
- Pas teksten aan in de content-bestanden in `src/content/` (zie de tabel in README.md), niet in losse HTML.
- Nieuwe pagina's en onderdelen altijd als Next.js-pagina of React-component in de bestaande structuur, met de bestaande stijlen. Nooit losse HTML/CSS-pagina's naast de site zetten.
- Elke nieuwe pagina krijgt metadata via `buildMetadata` (`src/lib/seo.ts`), één H1, en een vermelding in `src/app/sitemap.ts`.
- Afbeeldingen: `.webp` of `.jpg`, ongeveer 2000 px breed, kleiner dan 300 KB, altijd met een beschrijvende alt-tekst. Vervangen = altijd een nieuwe bestandsnaam en de verwijzing aanpassen (anders toont de cache de oude foto). De bestanden in `_next/` krijgen bij elke build automatisch een nieuwe naam.
- Huisstijl: kleuren en lettertype staan in `src/app/globals.css`. Hoofdgroen #3F6E5D, felgroen #4ADE80 enkel voor knoppen, tekst #1E3A2F, lettertype Gilroy.
- Geen verzonnen reviews, projecten, cijfers of teamleden. Enkel echte gegevens van VB-TEC.
- Geen tracking of cookies toevoegen zonder cookiebanner.

## Controleren na elke wijziging
1. `npm run dev` en de gewijzigde pagina bekijken op laptop- en gsm-breedte.
2. `npm run export` moet zonder fouten eindigen.
3. Als knoppen of formulieren geraakt zijn: de testlijst uit hoofdstuk 6 van de handleiding opnieuw doorlopen.

## Online zetten
`npm run export` maakt `website-online.zip`. De inhoud daarvan gaat naar de hoofdmap van de hosting.
