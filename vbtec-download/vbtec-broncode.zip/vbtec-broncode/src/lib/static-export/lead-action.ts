// Stand-in for the lead Server Action in the GitHub Pages static export (aliased in
// next.config.ts). Pages has no server, so this validates with the same rules and shows the
// success screen; the lead itself goes out as a pre-filled e-mail to VB-TEC.
import { firstName, leadFromFormData, validateLead, type LeadState } from "@/lib/lead-schema";

let submissionCounter = 0;

export async function submitLeadAction(_prev: LeadState, formData: FormData): Promise<LeadState> {
  const values = leadFromFormData(formData);
  const fieldErrors = validateLead(values);
  if (Object.keys(fieldErrors).length > 0) {
    submissionCounter += 1;
    return { status: "error", fieldErrors, values, submissionId: submissionCounter };
  }
  // No server on a static host: hand the lead to the visitor's mail app, addressed to VB-TEC,
  // so nothing is lost (same approach as the Dagklok forms).
  if (typeof window !== "undefined") {
    const labels: Record<string, string> = {
      naam: "Naam", email: "E-mail", telefoon: "Telefoon", straat: "Straat", huisnummer: "Nr.",
      postcode: "Postcode", gemeente: "Gemeente", interesse: "Interesse", verbruikType: "Verbruik (type)",
      verbruikWaarde: "Verbruik", woningType: "Woning", bericht: "Bericht",
    };
    const lines = Object.entries(values as Record<string, unknown>)
      .filter(([, v]) => v !== undefined && v !== null && String(v).trim() !== "")
      .map(([k, v]) => `${labels[k] ?? k}: ${Array.isArray(v) ? v.join(", ") : String(v)}`);
    const href = `mailto:info@vbtec.be?subject=${encodeURIComponent("Offerteaanvraag via de website")}&body=${encodeURIComponent(["Aanvraag via vbtec.be", "", ...lines].join("\n"))}`;
    window.location.href = href;
  }
  return { status: "success", firstName: firstName(values.naam) };
}
