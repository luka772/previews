import Link from "next/link";
import { routes } from "@/lib/routes";
import { BatteryIcon, CarIcon, FanIcon, PulseIcon, SunIcon } from "./icons";
import styles from "./Products.module.css";

/*
 * VB-TEC: each card is built in code (rounded outline card + transparent product
 * cut-out that rises out of it), so every card has the same size, label size and
 * clean edges. Cut-outs live in /images/products/cutout/.
 */
const products = [
  { label: "Zonnepanelen", href: routes.service("zonnepanelen"), image: "product-zonnepanelen", alt: "Een zwart zonnepaneel", Icon: SunIcon },
  { label: "Omvormers", href: routes.service("omvormers"), image: "product-omvormers", alt: "Een witte omvormer", Icon: PulseIcon },
  { label: "Thuisbatterijen", href: routes.service("thuisbatterij"), image: "product-thuisbatterij", alt: "Een witte thuisbatterij", Icon: BatteryIcon },
  { label: "Laadpalen", href: routes.service("laadpalen"), image: "product-laadpalen", alt: "Een zwarte laadpaal met kabel", Icon: CarIcon },
  { label: "PVT-panelen", href: routes.service("pvt-panelen"), image: "product-pvt-panelen", alt: "Een PVT-paneel met koperen leidingen aan de achterkant", Icon: SunIcon },
  { label: "Warmtepompen", href: routes.service("lucht-water-warmtepomp"), image: "product-lucht-water-warmtepomp", alt: "Een buitenunit van een warmtepomp", Icon: FanIcon, wide: true },
];

const base = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

// Extra services without a product cut-out yet (05 §0.3-5): shown as tags.
const extra = [
  { label: "Airco (lucht-lucht)", href: routes.service("lucht-lucht-warmtepomp") },
];

export default function ProductsSection() {
  return (
    <section className={styles.section} aria-labelledby="products-heading" data-header-tone="light">
      <ul className={styles.row}>
        {products.map(({ label, href, image, alt, Icon, wide }) => (
          <li key={label} className={styles.item}>
            <Link href={href} className={styles.link}>
              <img
                src={`${base}/images/products/cutout/${image}.webp`}
                alt={alt}
                loading="lazy"
                decoding="async"
                className={`${styles.image} ${wide ? styles.imageWide : ""}`}
              />
              <span className={styles.label}>{label}</span>
              <span className={styles.iconCircle}>
                <Icon className={styles.icon} />
              </span>
            </Link>
          </li>
        ))}
      </ul>
      <div className={styles.strip}>
        <h2 id="products-heading" className={styles.stripTitle}>
          Eén systeem, niet één product
        </h2>
        <p className={styles.extra}>
          <span className={styles.extraLabel}>Ook:</span>
          {extra.map((e) => (
            <Link key={e.href} href={e.href} className={styles.extraTag}>
              {e.label}
            </Link>
          ))}
          <Link href={routes.diensten()} className={styles.allLink}>
            Alle diensten
          </Link>
        </p>
      </div>
    </section>
  );
}
