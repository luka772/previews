"use client";

import { useEffect } from "react";

/** Counters, gallery lightbox and mailto forms of the Dagklok pages (from site.js). */
export default function DkSiteScript() {
  useEffect(() => {
    const $ = <T extends Element = HTMLElement>(s: string, r: ParentNode = document) => r.querySelector<T>(s);
    const $$ = <T extends Element = HTMLElement>(s: string, r: ParentNode = document) => Array.from(r.querySelectorAll<T>(s));
    const root = $(".dk-page");
    if (!root) return;
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const nf = new Intl.NumberFormat("nl-BE");
    const obs: IntersectionObserver[] = [];
    $$("[data-num]", root).forEach((el) => {
      const n = Number(el.getAttribute("data-num"));
      if (reduce || !("IntersectionObserver" in window)) {
        el.textContent = nf.format(n);
        return;
      }
      el.textContent = "0";
      const o = new IntersectionObserver(
        (es) => {
          if (!es[0].isIntersecting) return;
          o.disconnect();
          const t0 = performance.now();
          const step = (t: number) => {
            let f = Math.min(1, (t - t0) / 1500);
            f = 1 - Math.pow(1 - f, 3);
            el.textContent = nf.format(Math.round(n * f));
            if (f < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        },
        { threshold: 0.5 },
      );
      o.observe(el);
      obs.push(o);
    });
    // Lightbox
    const lb = $("#lightbox", root);
    const lbImg = lb ? $<HTMLImageElement>("img", lb) : null;
    const items = $$<HTMLAnchorElement>(".gallery a", root);
    let idx = 0;
    const show = (i: number) => {
      if (!lbImg) return;
      idx = (i + items.length) % items.length;
      lbImg.src = items[idx].getAttribute("href") ?? "";
      lbImg.alt = $<HTMLImageElement>("img", items[idx])?.alt ?? "";
    };
    const close = () => {
      if (!lb || lb.hidden) return;
      lb.hidden = true;
      document.documentElement.style.overflow = "";
    };
    items.forEach((a, i) =>
      a.addEventListener("click", (e) => {
        if (!lb) return;
        e.preventDefault();
        show(i);
        lb.hidden = false;
        document.documentElement.style.overflow = "hidden";
      }),
    );
    if (lb) {
      $(".lb-close", lb)?.addEventListener("click", close);
      $(".lb-prev", lb)?.addEventListener("click", () => show(idx - 1));
      $(".lb-next", lb)?.addEventListener("click", () => show(idx + 1));
      lb.addEventListener("click", (e) => {
        if (e.target === lb) close();
      });
    }
    const onKey = (e: KeyboardEvent) => {
      if (!lb || lb.hidden) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") show(idx - 1);
      if (e.key === "ArrowRight") show(idx + 1);
    };
    addEventListener("keydown", onKey);
    // File label
    $$<HTMLInputElement>(".file input[type=file]", root).forEach((inp) =>
      inp.addEventListener("change", () => {
        const s = inp.parentElement?.querySelector(".file__name");
        if (s) s.textContent = inp.files?.[0] ? inp.files[0].name : "Nog geen bestand gekozen";
      }),
    );
    // Forms: open a filled-in e-mail to VB-TEC (static hosting, no server).
    const LABELS: Record<string, string> = { bedrijfsnaam: "Bedrijfsnaam", sector: "Sector", voornaam: "Voornaam", achternaam: "Achternaam", naam: "Naam", functie: "Functie", gsm: "Gsm", telefoon: "Telefoon", email: "E-mail", interesse: "Interesse", bericht: "Bericht", vraag: "Vraag", motivatie: "Motivatie" };
    $$<HTMLFormElement>("form.js-form", root).forEach((form) =>
      form.addEventListener("submit", (ev) => {
        ev.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }
        const fd = new FormData(form);
        const seen: Record<string, boolean> = {};
        const lines: string[] = [];
        let cv = false;
        fd.forEach((v, k) => {
          if (typeof v !== "string") {
            if (v && (v as File).name) cv = true;
            return;
          }
          if (seen[k]) return;
          seen[k] = true;
          const val = fd.getAll(k).filter((x) => typeof x === "string" && x).join(", ");
          lines.push(`${LABELS[k] ?? k}: ${val || "-"}`);
        });
        const isJob = !!form.querySelector("input[type=file]");
        if (isJob) lines.push("", cv ? "Mijn cv voeg ik als bijlage toe aan deze mail." : "");
        const subject = isJob ? "Sollicitatie: verkoper duurzame energie" : location.pathname.includes("bedrijven") ? "Offerteaanvraag bedrijf" : "Offerteaanvraag";
        const href = `mailto:info@vbtec.be?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(lines.join("\n"))}`;
        const status = $(".status", form);
        if (status) {
          status.hidden = false;
          status.textContent = isJob ? "Bijna klaar: je mail staat klaar. Voeg je cv toe als bijlage en druk op Verzenden. " : "Bijna klaar: je aanvraag staat klaar in je mailprogramma. Druk daar nog op Verzenden. ";
          const a = document.createElement("a");
          a.href = href;
          a.textContent = "Opent er niets? Klik hier";
          a.style.fontWeight = "700";
          status.append(a, " of bel +32 51 15 31 12.");
        }
        location.href = href;
      }),
    );
    return () => {
      obs.forEach((o) => o.disconnect());
      removeEventListener("keydown", onKey);
    };
  }, []);
  return null;
}
