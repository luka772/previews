"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import styles from "./Calculator.module.css";

// Besparingscalculator (from Levi's VB-TEC site), in the Dagklok design.
// Indicative assumptions for Flanders (2026). Tweak here.
const PRICE = 0.32; // €/kWh bought from the grid
const INJECTION = 0.04; // €/kWh fed back
const COST_PER_KWP = 1250; // € incl. installation, 6% VAT
const COST_PER_BATTERY_KWH = 480;
const BATTERY_FIXED = 900;
const EV_KWH = 2500;
const CO2_PER_KWH = 0.16; // kg
const YEARS = 20;

const ROOFS = [
  { key: "zuid", label: "Zuid", yield: 950 },
  { key: "ow", label: "Oost-West", yield: 830 },
  { key: "plat", label: "Plat dak", yield: 880 },
] as const;
type RoofKey = (typeof ROOFS)[number]["key"];

const eur = (n: number) => n.toLocaleString("nl-BE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });

function useAnimated(value: number) {
  const [v, setV] = useState(value);
  const from = useRef(value);
  useEffect(() => {
    const start = from.current;
    const t0 = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const f = Math.min(1, (t - t0) / 600);
      const e = 1 - Math.pow(1 - f, 3);
      const cur = start + (value - start) * e;
      setV(cur);
      from.current = cur;
      if (f < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return v;
}

export default function Calculator() {
  const [usage, setUsage] = useState(4000);
  const [roof, setRoof] = useState<RoofKey>("zuid");
  const [battery, setBattery] = useState(true);
  const [ev, setEv] = useState(false);

  const r = useMemo(() => {
    const y = ROOFS.find((x) => x.key === roof)!.yield;
    const consumption = usage + (ev ? EV_KWH : 0);
    const kwp = Math.min(14, Math.max(2, Math.round((consumption / y) * 10) / 10));
    const production = kwp * y;
    const selfFraction = Math.min(0.82, 0.34 + (ev ? 0.1 : 0) + (battery ? 0.32 : 0));
    const selfUsed = Math.min(production * selfFraction, consumption);
    const injected = production - selfUsed;
    const batteryKwh = battery ? Math.min(15, Math.max(5, Math.round((consumption / 1000) * 1.4))) : 0;
    const investment = kwp * COST_PER_KWP + (battery ? batteryKwh * COST_PER_BATTERY_KWH + BATTERY_FIXED : 0);
    const savings = selfUsed * PRICE + injected * INJECTION;
    const payback = investment / savings;
    const cumulative = Array.from({ length: YEARS + 1 }, (_, i) => savings * i * (1 + 0.015 * i) - investment);
    return { kwp, batteryKwh, investment, savings, payback, cumulative, net: cumulative[YEARS], co2: (production * CO2_PER_KWH * YEARS) / 1000 };
  }, [usage, roof, battery, ev]);

  const savings = useAnimated(r.savings);
  const net = useAnimated(r.net);
  const fill = ((usage - 1500) / (12000 - 1500)) * 100;
  const min = Math.min(...r.cumulative);
  const max = Math.max(...r.cumulative);
  const zeroY = (max / (max - min)) * 100;

  return (
    <section id="calculator" className={styles.calc} data-header-tone="dark" aria-labelledby="calc-title">
      <div className={styles.inner}>
        <div className={styles.head}>
          <div>
            <span className={styles.label}>Besparingscalculator</span>
            <h2 id="calc-title" className={styles.title}>
              Hoeveel bespaar <em>jij</em>?
            </h2>
          </div>
          <p className={styles.intro}>Een eerste indicatie in 20 seconden. Bij je offerte rekent onze ingenieur het exact uit op basis van je echte meterdata.</p>
        </div>

        <div className={styles.grid}>
          <div className={styles.inputs}>
            <div className={styles.row}>
              <label htmlFor="calc-usage">Jaarlijks stroomverbruik</label>
              <span className={styles.big}>
                {usage.toLocaleString("nl-BE")} <small>kWh</small>
              </span>
            </div>
            <input
              id="calc-usage"
              className={styles.range}
              type="range"
              min={1500}
              max={12000}
              step={100}
              value={usage}
              onChange={(e) => setUsage(+e.target.value)}
              style={{ ["--fill" as string]: `${fill}%` }}
            />
            <div className={styles.scale}>
              <span>Appartement</span>
              <span>Gemiddeld gezin</span>
              <span>Groot verbruik</span>
            </div>

            <p className={styles.q}>Oriëntatie van je dak</p>
            <div className={styles.seg} role="radiogroup" aria-label="Oriëntatie van je dak">
              {ROOFS.map((x) => (
                <button key={x.key} type="button" role="radio" aria-checked={roof === x.key} className={roof === x.key ? styles.segOn : undefined} onClick={() => setRoof(x.key)}>
                  {x.label}
                </button>
              ))}
            </div>

            <p className={styles.q}>Extra&apos;s</p>
            <div className={styles.toggles}>
              {[
                { on: battery, set: setBattery, label: "Thuisbatterij" },
                { on: ev, set: setEv, label: "Elektrische wagen" },
              ].map((t) => (
                <button key={t.label} type="button" aria-pressed={t.on} className={`${styles.toggle} ${t.on ? styles.toggleOn : ""}`} onClick={() => t.set(!t.on)}>
                  <span>{t.label}</span>
                  <span className={styles.switch} aria-hidden="true">
                    <span />
                  </span>
                </button>
              ))}
            </div>

            <div className={styles.specs}>
              <div>
                <b>{r.kwp.toLocaleString("nl-BE")} kWp</b>
                <span>panelen (± {Math.round((r.kwp * 1000) / 430)} st.)</span>
              </div>
              <div>
                <b>{battery ? `${r.batteryKwh} kWh` : "–"}</b>
                <span>batterij</span>
              </div>
              <div>
                <b>{eur(r.investment)}</b>
                <span>investering</span>
              </div>
            </div>
          </div>

          <div className={styles.results}>
            <p className={styles.small}>Geschatte besparing per jaar</p>
            <p className={styles.huge} aria-live="polite">
              {eur(savings)}
            </p>

            <div className={styles.kpis}>
              <div>
                <b>{r.payback.toLocaleString("nl-BE", { maximumFractionDigits: 1 })} jaar</b>
                <span>terugverdientijd</span>
              </div>
              <div>
                <b>{eur(net)}</b>
                <span>netto winst na {YEARS} jaar</span>
              </div>
              <div>
                <b>{r.co2.toLocaleString("nl-BE", { maximumFractionDigits: 1 })} ton</b>
                <span>CO₂ vermeden ({YEARS} j)</span>
              </div>
            </div>

            <div className={styles.chartHead}>
              <span>Cumulatieve cashflow</span>
              <span className={styles.legend}>
                <i className={styles.neg} /> investering <i className={styles.pos} /> winst
              </span>
            </div>
            <div className={styles.chart} aria-hidden="true">
              <span className={styles.zero} style={{ top: `${zeroY}%` }} />
              {r.cumulative.map((v, i) => {
                const h = (Math.abs(v) / (max - min)) * 100;
                return (
                  <div key={i} className={styles.col}>
                    <span className={v >= 0 ? styles.barPos : styles.barNeg} style={{ top: `${v >= 0 ? zeroY - h : zeroY}%`, height: `${h}%`, transitionDelay: `${i * 12}ms` }} />
                  </div>
                );
              })}
            </div>
            <div className={styles.years}>
              <span>Jaar 0</span>
              <span>Jaar 10</span>
              <span>Jaar 20</span>
            </div>

            <div className={styles.foot}>
              <p>Indicatief. Stroomprijs € 0,32/kWh, injectie € 0,04/kWh, 1,5% jaarlijkse prijsstijging, 6% btw.</p>
              <a href="#berekening" className={styles.cta}>
                Vraag je offerte aan
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
