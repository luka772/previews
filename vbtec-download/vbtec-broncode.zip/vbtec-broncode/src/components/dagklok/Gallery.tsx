"use client";

import { useCallback, useEffect, useState } from "react";
import styles from "./Gallery.module.css";

export type GalleryImage = { src: string; alt: string; width: number; height: number };

/** Photo grid with a simple lightbox (Luka's Dagklok "projecten" page). */
export default function Gallery({ images }: { images: GalleryImage[] }) {
  const [open, setOpen] = useState<number | null>(null);
  const close = useCallback(() => setOpen(null), []);
  const step = useCallback((d: number) => setOpen((i) => (i === null ? i : (i + d + images.length) % images.length)), [images.length]);
  useEffect(() => {
    if (open === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, close, step]);
  return (
    <>
      <ul className={styles.grid}>
        {images.map((img, i) => (
          <li key={img.src}>
            <a
              href={img.src}
              onClick={(e) => {
                e.preventDefault();
                setOpen(i);
              }}
            >
              <img src={img.src} alt={img.alt} width={img.width} height={img.height} loading="lazy" decoding="async" />
            </a>
          </li>
        ))}
      </ul>
      {open !== null && (
        <div className={styles.lightbox} role="dialog" aria-modal="true" aria-label="Projectfoto" onClick={close}>
          <img src={images[open].src} alt={images[open].alt} onClick={(e) => e.stopPropagation()} />
          <button type="button" className={styles.close} onClick={close}>
            Sluiten
          </button>
          <button type="button" className={`${styles.nav} ${styles.prev}`} aria-label="Vorige foto" onClick={(e) => { e.stopPropagation(); step(-1); }}>
            ‹
          </button>
          <button type="button" className={`${styles.nav} ${styles.next}`} aria-label="Volgende foto" onClick={(e) => { e.stopPropagation(); step(1); }}>
            ›
          </button>
        </div>
      )}
    </>
  );
}
