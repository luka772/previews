import { DK_PAGES } from "@/content/dagklok-pages";
import { buildMetadata } from "@/lib/seo";
import "./dagklok.css";
import DkSiteScript from "./DkSiteScript";
import DkAanbodPage from "./pages/DkAanbodPage";
import DkBatterijopslagPage from "./pages/DkBatterijopslagPage";
import DkContactPage from "./pages/DkContactPage";
import DkIndexPage from "./pages/DkIndexPage";
import DkLaadinfrastructuurPage from "./pages/DkLaadinfrastructuurPage";
import DkOpMaatPage from "./pages/DkOpMaatPage";
import DkPartnersPage from "./pages/DkPartnersPage";
import DkProjectenPage from "./pages/DkProjectenPage";
import DkVacaturePage from "./pages/DkVacaturePage";
import DkZonnepanelenPage from "./pages/DkZonnepanelenPage";

const BODIES: Record<string, () => React.JSX.Element> = {
  "aanbod": DkAanbodPage,
  "batterijopslag": DkBatterijopslagPage,
  "contact": DkContactPage,
  "index": DkIndexPage,
  "laadinfrastructuur": DkLaadinfrastructuurPage,
  "op-maat": DkOpMaatPage,
  "partners": DkPartnersPage,
  "projecten": DkProjectenPage,
  "vacature": DkVacaturePage,
  "zonnepanelen": DkZonnepanelenPage,
};


export function dkMetadata(slug: string) {
  const p = DK_PAGES[slug];
  return buildMetadata({ title: p.title, absoluteTitle: true, description: p.description, path: p.path });
}

/** A page from Luka's Dagklok site (vbtec.be content) under Levi's menu and footer. */
export default function DkPage({ slug }: { slug: string }) {
  const Body = BODIES[slug];
  return (
    <>
      <div className="dk sub dk-page" data-header-tone="dark">
        <Body />
      </div>
      <DkSiteScript />
    </>
  );
}
