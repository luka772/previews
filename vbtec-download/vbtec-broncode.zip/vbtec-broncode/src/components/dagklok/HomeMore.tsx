import Link from "next/link";
import { JsonLd } from "@/components/ui";
import { routes } from "@/lib/routes";
import styles from "./HomeMore.module.css";

// Homepage "Alles over VB-TEC": extra content behind dropdowns (native <details>), so the
// page stays calm while every answer stays in the HTML for Google and AI assistants.
type Item = { q: string; a: string[]; link?: { label: string; href: string } };

const ITEMS: Item[] = [
  {
    q: "Wie is VB-TEC?",
    a: [
      "VB-TEC is een energie-installateur uit Pittem, in West-Vlaanderen. VB-TEC plaatst zonnepanelen, thuisbatterijen, laadpalen en warmtepompen, voor particulieren en voor bedrijven, met eigen installatieploegen.",
      "Tot nu toe plaatste VB-TEC 25.272 zonnepanelen, 250 warmtepompen en 150 laadpalen. Your energy, our power: jij wekt de energie op, VB-TEC zorgt dat alles samen werkt.",
    ],
    link: { label: "Over VB-TEC", href: routes.overOns() },
  },
  {
    q: "Welke zonnepanelen plaatst VB-TEC?",
    a: [
      "Zonnepanelen blijven een sterke investering: je bespaart tot dertig jaar lang op je energiefactuur en je wordt minder afhankelijk van schommelende energieprijzen.",
      "VB-TEC komt eerst bij je langs. We bekijken je verbruik, de beschikbare oppervlakte en de oriëntatie van je dak, en hoe we het technisch en esthetisch het best aanpakken. Je opbrengst volg je daarna eenvoudig in de app.",
    ],
    link: { label: "Zonnepanelen bij VB-TEC", href: routes.service("zonnepanelen") },
  },
  {
    q: "Heb ik een thuisbatterij nodig?",
    a: [
      "Zonder batterij gaat een groot deel van je zonnestroom naar het net, tegen een kleine vergoeding. Met een thuisbatterij van VB-TEC gebruik je tot 70% van de energie die je zonnepanelen opwekken zelf, en heb je ook stroom tijdens een black-out.",
      "Een batterij loont niet in elke woning. VB-TEC rekent het eerlijk uit, en raadt hem af als hij zichzelf niet terugverdient.",
    ],
    link: { label: "Thuisbatterij bij VB-TEC", href: routes.service("thuisbatterij") },
  },
  {
    q: "Kan VB-TEC een laadpaal bij mij thuis plaatsen?",
    a: [
      "Ja. Een laadpaal van VB-TEC laadt je elektrische of hybride wagen veilig op, bij voorkeur met je eigen zonnestroom. Dankzij slim energiebeheer laad je een stuk goedkoper.",
      "VB-TEC ontzorgt je volledig: van de aansluiting op je meterkast tot het testen en activeren.",
    ],
    link: { label: "Laadpaal bij VB-TEC", href: routes.service("laadpalen") },
  },
  {
    q: "Welke warmtepomp plaatst VB-TEC?",
    a: [
      "VB-TEC plaatst lucht-water warmtepompen van Daikin. Ze halen warmte uit de buitenlucht, verwarmen in de winter, verkoelen in de zomer en passen uitstekend bij vloer- en wandverwarming.",
      "Voor wie enkel enkele ruimtes wil verwarmen of koelen, plaatst VB-TEC ook lucht-lucht warmtepompen (airco).",
    ],
    link: { label: "Warmtepomp bij VB-TEC", href: routes.service("lucht-water-warmtepomp") },
  },
  {
    q: "Werkt VB-TEC ook voor bedrijven?",
    a: [
      "Ja. Voor bedrijven plaatst VB-TEC zonnepanelen op grote daken, batterijopslag om pieken en het capaciteitstarief onder controle te houden, en laadinfrastructuur voor je vloot en bezoekers. Grotere projecten tekenen we op maat van je site.",
    ],
    link: { label: "VB-TEC voor bedrijven", href: "/bedrijven" },
  },
  {
    q: "Hoe verloopt een offerte bij VB-TEC?",
    a: [
      "Je vraagt je offerte aan via het formulier of telefonisch. VB-TEC komt langs om je woning en je verbruik te bekijken, en je krijgt een voorstel met de combinaties naast elkaar: kosten, premies en terugverdientijd. Jij beslist, zonder druk. Daarna plaatsen onze eigen ploegen alles en volgen we je installatie op.",
      "Je ontvangt je offerte binnen de 4 werkdagen.",
    ],
    link: { label: "Hoe VB-TEC werkt", href: routes.hoeWeWerken() },
  },
  {
    q: "Wat kost een installatie van VB-TEC?",
    a: [
      "Dat hangt af van je woning, je verbruik en de combinatie die je kiest. De besparingscalculator hierboven geeft je in 20 seconden een eerste indicatie. In je offerte rekent VB-TEC het exact uit, met je echte verbruik.",
    ],
    link: { label: "Vergelijk de opties", href: routes.vergelijken() },
  },
  {
    q: "In welke regio werkt VB-TEC?",
    a: [
      "VB-TEC werkt vanuit Pittem (West-Vlaanderen), met eigen installatieploegen. Twijfel je of we tot bij jou komen? Bel of mail ons gerust, dan bekijken we het samen.",
    ],
  },
  {
    q: "Hoe contacteer ik VB-TEC?",
    a: [
      "VB-TEC BV, Brugsesteenweg 81, 8740 Pittem. Kantoor: 051 15 31 15. Sales: 051 15 31 12. E-mail: info@vbtec.be.",
    ],
    link: { label: "Naar contact", href: routes.contact() },
  },
];

export default function HomeMore() {
  const faq = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: ITEMS.map((i) => ({ "@type": "Question", name: i.q, acceptedAnswer: { "@type": "Answer", text: i.a.join(" ") } })),
  };
  return (
    <section className={styles.more} data-header-tone="light" aria-labelledby="meer-title">
      <div className={styles.inner}>
        <div className={styles.head}>
          <span className={styles.label}>Meer weten</span>
          <h2 id="meer-title" className={styles.title}>
            Alles over VB-TEC
          </h2>
          <p className={styles.lead}>Klik open wat je wil weten. Korte antwoorden, met een link naar de volledige uitleg.</p>
        </div>
        <div className={styles.list}>
          {ITEMS.map((item) => (
            <details key={item.q} className={styles.item}>
              <summary>
                <span>{item.q}</span>
                <span className={styles.plus} aria-hidden="true" />
              </summary>
              <div className={styles.body}>
                {item.a.map((p) => (
                  <p key={p.slice(0, 24)}>{p}</p>
                ))}
                {item.link && (
                  <Link href={item.link.href} className={styles.link}>
                    {item.link.label} →
                  </Link>
                )}
              </div>
            </details>
          ))}
        </div>
      </div>
      <JsonLd data={faq} />
    </section>
  );
}
