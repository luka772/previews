"use client";

import { useEffect } from "react";

type W = Window & { ScrollCraft?: { mount: (root: Element) => unknown }; __DK_RUN__?: () => void; __DK_BASE__?: string };

function load(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.async = false;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error(src));
    document.body.appendChild(s);
  });
}

/** Boots Luka's Dagklok scroll engine (scrollcraft.js) and page choreography (dag.js) on the homepage. */
export default function DagklokLoader({ rootId }: { rootId: string }) {
  useEffect(() => {
    const w = window as W;
    const base = process.env.NEXT_PUBLIC_BASE_PATH ?? "";
    w.__DK_BASE__ = base;
    const root = document.getElementById(rootId);
    if (!root) return;
    // Pick a clip the browser can decode before the engine reads data-sc-src.
    const v = root.querySelector<HTMLVideoElement>("#dag video");
    if (v && !v.canPlayType('video/mp4; codecs="avc1.640028"') && v.canPlayType('video/webm; codecs="vp9"')) {
      v.setAttribute("data-sc-src", `${base}/dagklok/dag.webm`);
      v.setAttribute("data-sc-src-mobile", `${base}/dagklok/dag-m.webm`);
    }
    // Scroll hint in the hero: fade it out as soon as the visitor starts scrolling.
    const onScroll = () => root.classList.toggle("dk-scrolled", scrollY > 40);
    addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    let cancelled = false;
    (async () => {
      if (!w.ScrollCraft) await load(`${base}/dagklok/scrollcraft.js`);
      if (!w.__DK_RUN__) await load(`${base}/dagklok/dag.js`);
      if (cancelled || !w.ScrollCraft || !w.__DK_RUN__) return;
      w.ScrollCraft.mount(root);
      w.__DK_RUN__();
      requestAnimationFrame(() => dispatchEvent(new Event("resize")));
    })().catch(() => {});
    return () => {
      cancelled = true;
      removeEventListener("scroll", onScroll);
    };
  }, [rootId]);
  return null;
}
