// Product blocks from vbtec.be (Dagklok design) shown on the matching dienst page.
import DkZonnepanelenService from "./DkZonnepanelenService";
import DkThuisbatterijService from "./DkThuisbatterijService";
import DkLaadpalenService from "./DkLaadpalenService";
import DkLuchtWaterWarmtepompService from "./DkLuchtWaterWarmtepompService";

export const DK_SERVICE_BODIES: Record<string, () => React.JSX.Element> = {
  zonnepanelen: DkZonnepanelenService,
  thuisbatterij: DkThuisbatterijService,
  laadpalen: DkLaadpalenService,
  "lucht-water-warmtepomp": DkLuchtWaterWarmtepompService,
};
