// Homepage: hero (Dagklok design).
// Static markup as React components; the Dagklok scripts (public/dagklok) add the scroll behaviour.
const B = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

export default function DkHero() {
  return (
    <>
      <section id={"ochtend"} className={"hero"} data-sc-act={"pin"} data-sc-span={"1.8"} data-sc-drift={"#FFFFFF"} data-hour={"6.5 9"}><div data-sc-stage><img className={"plane plane--lucht"} src={`${B}/dagklok/img/hero-lucht.webp`} alt={""} width={"2200"} height={"1244"} fetchPriority={"high"} /><h1 aria-label={"Your energy, our power"}>{" "}<span className={"hero__back"} aria-hidden={"true"}>{"Your energy,"}</span>{" "}</h1><img className={"plane plane--huis"} src={`${B}/dagklok/img/hero-huis.webp`} alt={"Een Vlaamse gezinswoning bij dageraad, met zwarte zonnepanelen op het dak, een warmtepomp tegen de gevel en een elektrische auto in de carport."} width={"2200"} height={"1244"} fetchPriority={"high"} /><div className={"hero__mist"} aria-hidden={"true"}></div><img className={"plane plane--haag"} src={`${B}/dagklok/img/hero-haag.webp`} alt={""} width={"2200"} height={"1244"} /><div className={"hero__floor"} aria-hidden={"true"}></div><div className={"hero__front"}><span className={"h1-2"} aria-hidden={"true"}>{"our power"}</span><p>{"Van zon tot opslag en laden: "}<b>{"wij bouwen uw complete energiesysteem."}</b></p></div><a className={"scroll-hint"} href={"#dag"} aria-label={"Scroll naar beneden"}><span className={"scroll-hint__txt"}>{"Scroll"}</span><span className={"scroll-hint__icon"} aria-hidden={"true"}><i></i></span></a></div></section>
    </>
  );
}
