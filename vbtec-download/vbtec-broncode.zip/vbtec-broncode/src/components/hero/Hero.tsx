import styles from "./Hero.module.css";

// Homepage hero: the VB-TEC slogan exactly as in Luka's Dagklok design.
// Three photo planes (sky, house, hedge). "Your energy," sits between the sky and
// the house, so the house stands in front of it; "our power" sits in front of everything.
// The <h1> is `display: contents`, so both halves stay real, visible heading text
// while living on different planes. The shared site header sits on top of this frame.
const base = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

export default function Hero() {
  return (
    <section className={styles.frame} data-header-tone="dark" aria-labelledby="home-title">
      <div className={styles.hero}>
        <img
          className={`${styles.plane} ${styles.planeSky}`}
          src={`${base}/images/dagklok/hero-lucht.webp`}
          alt=""
          width={2200}
          height={1244}
          fetchPriority="high"
        />
        <h1 id="home-title" className={styles.title}>
          <span className={styles.back}>Your energy,</span> <span className={styles.front}>our power</span>
        </h1>
        <img
          className={`${styles.plane} ${styles.planeHouse}`}
          src={`${base}/images/dagklok/hero-huis.webp`}
          alt="Een Vlaamse gezinswoning bij dageraad, met zwarte zonnepanelen op het dak, een warmtepomp tegen de gevel en een elektrische auto met laadpaal en thuisbatterij in de carport."
          width={2200}
          height={1244}
          fetchPriority="high"
        />
        <div className={styles.mist} aria-hidden="true" />
        <img
          className={`${styles.plane} ${styles.planeHedge}`}
          src={`${base}/images/dagklok/hero-haag.webp`}
          alt=""
          width={2200}
          height={1244}
        />
        <div className={styles.floor} aria-hidden="true" />
        <p className={styles.sub}>
          Van zon tot opslag en laden: <b>wij bouwen uw complete energiesysteem.</b>
        </p>
      </div>
    </section>
  );
}
