import Link from "next/link";
import { site } from "@/content/site";
import { routes } from "@/lib/routes";
import styles from "./Footer.module.css";

// VB-TEC footer in Luka's Dagklok design: logo + offer, two link columns, contact + socials.
// Comparisons, kennisbank and blog stay reachable through the main menu and sitemap.xml.
const base = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

const particulieren = [
  { label: "Home", href: routes.home() },
  { label: "Alle diensten", href: routes.diensten() },
  { label: "Zonnepanelen", href: routes.service("zonnepanelen") },
  { label: "Thuisbatterijen", href: routes.service("thuisbatterij") },
  { label: "Laadpalen", href: routes.service("laadpalen") },
  { label: "Warmtepompen", href: routes.service("lucht-water-warmtepomp") },
  { label: "Projecten", href: routes.projecten() },
];

const bedrijf = [
  { label: "Voor bedrijven", href: "/bedrijven" },
  { label: "Over ons", href: routes.overOns() },
  { label: "Hoe we werken", href: routes.hoeWeWerken() },
  { label: "Hoe het werkt", href: routes.hoeHetWerkt() },
  { label: "Kennisbank", href: routes.kennisbank() },
  { label: "Blog", href: routes.blog() },
  { label: "Vacature", href: "/vacature" },
  { label: "Contact", href: routes.contact() },
];

const socials = [
  { label: "Facebook", href: "https://www.facebook.com/profile.php?id=100057225408730" },
  { label: "Instagram", href: "https://www.instagram.com/vbtec_bv/" },
  { label: "LinkedIn", href: "https://www.linkedin.com/company/vb-tec/" },
];

export default function Footer() {
  return (
    <footer className={styles.ftr} data-header-tone="dark">
      <div className={styles.top}>
        <div className={styles.brand}>
          <img src={`${base}/brand/vbtec-logo-wit.png`} alt="VB-TEC" width={1137} height={1035} loading="lazy" className={styles.logo} />
          <p>Ontvang je offerte binnen de 4 werkdagen.</p>
          <Link href={routes.contactLead()} className={styles.cta}>
            Offerte aanvragen
          </Link>
        </div>

        <nav aria-label="Particulieren">
          <h2 className={styles.h}>Particulieren</h2>
          <ul className={styles.list}>
            {particulieren.map((l) => (
              <li key={l.href}>
                <Link href={l.href}>{l.label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="VB-TEC">
          <h2 className={styles.h}>VB-TEC</h2>
          <ul className={styles.list}>
            {bedrijf.map((l) => (
              <li key={l.href}>
                <Link href={l.href}>{l.label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className={styles.h}>Contact</h2>
          <address className={styles.address}>
            <span>
              {site.address.street}
              <br />
              {site.address.postalCode} {site.address.city}
            </span>
            <span>
              Kantoor <a href={site.phoneHref}>+32 51 15 31 15</a>
            </span>
            <span>
              Sales <a href={site.salesPhoneHref}>+32 51 15 31 12</a>
            </span>
            <a href={`mailto:${site.email}`}>{site.email}</a>
          </address>
          <h2 className={`${styles.h} ${styles.hGap}`}>Volg ons</h2>
          <ul className={styles.list}>
            {socials.map((s) => (
              <li key={s.href}>
                <a href={s.href} target="_blank" rel="noopener noreferrer">
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className={styles.bottom}>
        <span>© {site.copyrightYear} VB-TEC · Your energy, our power{site.vat ? ` · BTW ${site.vat}` : ""}</span>
        <span>
          <Link href={routes.privacy()}>Privacy</Link> ·{" "}
          <a href={`${base}${routes.sitemapXml()}`}>Sitemap</a>
        </span>
      </div>
    </footer>
  );
}
