import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { site } from "@/content/site";
import { SITE_URL } from "@/lib/routes";
import { organization, website } from "@/lib/schema";
import JsonLd from "@/components/ui/JsonLd";
import SiteHeader from "@/components/site/SiteHeader";
import Footer from "@/components/site/Footer";
import "./globals.css";

// Fonts load once here (04 §1.2); modules use var(--font-figtree) / var(--font-lexend)
// through the tokens --font-label / --font-ui. Manrope is the brand voice (body,
// headings and the heavy VBTEC wordmark).
// Dagklok huisstijl: Gilroy is the single brand typeface (light → heavy).
const gilroy = localFont({
  src: [
    { path: "./fonts/Gilroy-Light.woff2", weight: "300", style: "normal" },
    { path: "./fonts/Gilroy-Regular.woff2", weight: "400", style: "normal" },
    { path: "./fonts/Gilroy-Medium.woff2", weight: "500", style: "normal" },
    { path: "./fonts/Gilroy-Bold.woff2", weight: "700", style: "normal" },
    { path: "./fonts/Gilroy-Heavy.woff2", weight: "900", style: "normal" },
  ],
  variable: "--font-gilroy",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL), // PLACEHOLDER domain
  title: {
    default: "VB-TEC – energie-ingenieurs voor jouw woning",
    template: "%s | VB-TEC",
  },
  description: site.description,
  applicationName: site.name,
  openGraph: {
    type: "website",
    locale: "nl_BE",
    siteName: site.name,
  },
  twitter: { card: "summary_large_image" },
  robots: { index: true, follow: true },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#0b4a3f",
  colorScheme: "light",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="nl-BE" className={gilroy.variable} suppressHydrationWarning>
      <body suppressHydrationWarning>
        <SiteHeader />
        <main id="inhoud" tabIndex={-1}>
          {children}
        </main>
        <Footer />
        <JsonLd data={[organization(), website()]} />
      </body>
    </html>
  );
}
