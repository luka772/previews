import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("partners");

export default function Page() {
  return <DkPage slug={"partners"} />;
}
