import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("index");

export default function Page() {
  return <DkPage slug={"index"} />;
}
