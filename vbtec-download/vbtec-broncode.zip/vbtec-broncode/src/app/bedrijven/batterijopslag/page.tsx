import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("batterijopslag");

export default function Page() {
  return <DkPage slug={"batterijopslag"} />;
}
