import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("op-maat");

export default function Page() {
  return <DkPage slug={"op-maat"} />;
}
