import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("zonnepanelen");

export default function Page() {
  return <DkPage slug={"zonnepanelen"} />;
}
