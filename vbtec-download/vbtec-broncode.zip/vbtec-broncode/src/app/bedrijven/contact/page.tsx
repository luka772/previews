import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("contact");

export default function Page() {
  return <DkPage slug={"contact"} />;
}
