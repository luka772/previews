import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("aanbod");

export default function Page() {
  return <DkPage slug={"aanbod"} />;
}
