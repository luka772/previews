import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("laadinfrastructuur");

export default function Page() {
  return <DkPage slug={"laadinfrastructuur"} />;
}
