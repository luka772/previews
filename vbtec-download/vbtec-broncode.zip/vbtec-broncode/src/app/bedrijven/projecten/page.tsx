import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("projecten");

export default function Page() {
  return <DkPage slug={"projecten"} />;
}
