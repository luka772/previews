import { getFaqs } from "@/content/faqs";
import { routes } from "@/lib/routes";
import { buildMetadata } from "@/lib/seo";
import { relatedLinks } from "@/lib/links";
import PageHero from "@/components/sections/PageHero";
import RealProjects from "@/components/sections/RealProjects";
import Faq from "@/components/sections/Faq";
import LeadSection from "@/components/lead/LeadSection";
import { Section, SectionIntro } from "@/components/ui";
import Gallery from "@/components/dagklok/Gallery";

// /projecten: echte installaties van VB-TEC (geen verzonnen gezinnen of bedragen).
const PATH = routes.projecten();
const base = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

export const metadata = buildMetadata({
  title: "Projecten: zonnepanelen, batterijen, laadpalen en warmtepompen van VB-TEC",
  description:
    "Bekijk echte installaties van VB-TEC: zonnepanelen, thuisbatterijen, laadpalen en warmtepompen bij gezinnen in West-Vlaanderen, geplaatst door onze eigen ploegen.",
  path: PATH,
});

const PHOTOS = ["8684096f", "1388afd1", "2debc61f", "2001ec1c", "82fe1561", "a5bc82dd", "029c0540", "b89404f8", "c86e0723", "c13c4338", "1d495f58", "1e826310", "ffeebe6c", "44a2b30f"].map((id) => ({
  src: `${base}/images/projecten/${id}.webp`,
  alt: "Woning met zonnepanelen, geplaatst door VB-TEC",
  width: 1400,
  height: 1000,
}));

const FAQ = [
  {
    q: "Kan ik een installatie van VB-TEC bezoeken?",
    a: "Dat regelen we graag, als er in jouw buurt een klant is die daarvoor openstaat. Vaak is een gesprek over jouw eigen woning nuttiger: dan zie je meteen wat er bij jou kan. Vraag het gerust bij je offerteaanvraag.",
  },
  {
    q: "Wat als mijn woning anders is?",
    a: "Dat is bijna altijd zo, en daarom kopiëren we nooit een pakket van een ander project. Je krijgt een offerte op maat, met de combinaties naast elkaar en een eerlijk advies. Soms is dat een kleinere installatie dan je dacht, of eerst isoleren.",
  },
  ...getFaqs(["regio"]),
];

export default function ProjectenPage() {
  return (
    <>
      <PageHero
        variant="image"
        path={PATH}
        breadcrumb={[{ label: "Home", href: routes.home() }, { label: "Projecten" }]}
        eyebrow="Projecten"
        title="Laat je inspireren door onze laatste projecten"
        image={{ src: "/images/projecten/2001ec1c.webp", alt: "Luchtfoto van woningen met zonnepanelen", width: 2000, height: 1333 }}
        cta={{ label: "Offerte aanvragen", href: routes.lead() }}
      />

      <RealProjects />

      <Section bg="W" id="galerij" labelledBy="galerij-title">
        <SectionIntro eyebrow="Galerij" title="Gezinnen gingen je voor" titleId="galerij-title" lead="Je bent niet de eerste die zoekt naar een groene investering met het mooiste rendement. Laat je inspireren door hun woning." />
        <Gallery images={PHOTOS} />
      </Section>

      <LeadSection bron={PATH} heading="Ook een offerte voor jouw woning?" />

      <Faq title="Vragen over onze projecten" items={FAQ} relatedLinks={relatedLinks({ comparisons: ["met-of-zonder-thuisbatterij", "gasketel-vs-warmtepomp"] })} />
    </>
  );
}
