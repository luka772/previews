import { DATA, MYTH } from "@/content/home";
import { DataBand, Faq, PageHero, Statement } from "@/components/sections";
import LeadSection from "@/components/lead/LeadSection";
import { ComparisonCard, JsonLd } from "@/components/ui";
import { COMPARISON_GROUPS, getComparisonsByGroup, comparisons, v } from "@/content/comparisons";
import type { FaqItem } from "@/content/types";
import { getFaqs } from "@/content/faqs";
import { routes } from "@/lib/routes";
import { itemList } from "@/lib/schema";
import { buildMetadata } from "@/lib/seo";
import styles from "./_components/hub.module.css";
import LatestPosts from "@/components/sections/LatestPosts";

// /vergelijken – hub (05 §5.2): Hero + decision cards (W) → Hoe we vergelijken (D) → FAQ (W) → Lead (I).
export const metadata = buildMetadata({
  title: "Vergelijken: gasketel vs warmtepomp, met of zonder batterij",
  description:
    "Twijfel je tussen gasketel en warmtepomp, met of zonder batterij, PV of PVT? Eerlijke vergelijkingen met Vlaamse cijfers – inclusief wanneer het níet loont.",
  path: routes.vergelijken(),
});

const FAQ: FaqItem[] = [
  {
    q: "Hoe betrouwbaar zijn deze vergelijkingen?",
    a: "Elk cijfer komt uit een publieke bron, met de datum erbij, en staat bij de vergelijking vermeld. We rekenen met vlakke prijzen en zeggen welke aannames we maken. Het blijven gemiddelden: jouw verbruik, je woning en je contract kunnen het resultaat in beide richtingen doen kantelen.",
    aLong: "Daarom noemen we alle bedragen indicatief. Je persoonlijke berekening, op basis van je jaarafrekening en je woning, is de enige die telt.",
  },
  {
    q: "Waarom zeggen jullie soms dat iets niet loont?",
    a: "Omdat het zo is. Een batterij bij een klein verbruik, een warmtepomp in een slecht geïsoleerde woning met een zeer goedkoop gascontract: soms is de winst te klein. Wie je dan toch iets verkoopt, verliest je vertrouwen. Wij rekenen liever eerlijk en houden je als klant voor later.",
  },
  {
    q: "Met welke energieprijzen rekenen jullie?",
    a: `We gebruiken rekenwaarden voor een gemiddeld Vlaams gezin: stroom ${v("stroomprijsAllIn", { pre: "€ " })} per kWh all-in, gas ${v("gasprijsAllIn", { pre: "€ " })} per kWh all-in en een injectievergoeding van ${v("injectievergoeding")} cent. We herzien die cijfers minstens elk kwartaal, en in je eigen berekening rekenen we met jouw contract.`,
  },
  ...getFaqs(["berekening-kost"]),
];

export default function VergelijkenHub() {
  return (
    <>
      <PageHero
        variant="type"
        path={routes.vergelijken()}
        breadcrumb={[{ label: "Home", href: routes.home() }, { label: "Vergelijken" }]}
        eyebrow="Vergelijken"
        title="Twijfel je? Vergelijk eerlijk, met echte cijfers"
        lead="Gasketel of warmtepomp, met of zonder batterij, gewone panelen of PVT. Hier vind je per keuze het korte antwoord, de cijfers naast elkaar en – minstens zo belangrijk – wanneer het níet loont."
        cta={{ label: "Laat jouw situatie doorrekenen", href: routes.lead() }}
        trustLine
      >
        <div className={styles.groups}>
          {COMPARISON_GROUPS.map((g) => (
            <section key={g.key} className={styles.group} aria-labelledby={`groep-${g.key}`}>
              <div className={styles.groupHead}>
                <h2 id={`groep-${g.key}`} className={styles.groupTitle}>
                  {g.title}
                </h2>
                <p className={styles.groupIntro}>{g.intro}</p>
              </div>
              <ul className={styles.cards}>
                {getComparisonsByGroup(g.key).map((c) => (
                  <li key={c.slug}>
                    <ComparisonCard slug={c.slug} verdict={c.verdict} variant="grid" />
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      </PageHero>

      <DataBand
        id="hoe-we-vergelijken"
        intro={{
          eyebrow: "Hoe we vergelijken",
          title: "Dezelfde cijfers voor elke keuze.",
          lead: "Gedateerde rekenwaarden voor een gemiddeld Vlaams gezin, vlakke prijzen, geen voorspellingen.",
        }}
        mode="stats"
        stats={[
          { k: "stroomprijsAllIn", label: "Stroom per kWh, all-in", prefix: "€ " },
          { k: "gasprijsAllIn", label: "Gas per kWh, all-in", prefix: "€ " },
          { k: "scopRekenwaarde", label: "Rekenwaarde SCOP warmtepomp" },
          { k: "injectievergoeding", label: "Injectievergoeding", suffix: " c/kWh" },
        ]}
        whenTrue="Een gemiddelde is nooit jouw woning: een goedkoop gascontract of weinig verbruik overdag kan de uitkomst kantelen."
        assumptions={["stroomprijsAllIn", "gasprijsAllIn", "scopRekenwaarde", "injectievergoeding", "gasverbruikGezin", "stroomverbruikGezin"]}
        assumptionsNote={`Rekenwaarden voor een standaardgezin met ${v("gasverbruikGezin")} kWh gas en ${v("stroomverbruikGezin")} kWh stroom per jaar. We herzien ze elk kwartaal.`}
        cta={{ label: "Laat jouw situatie doorrekenen", href: routes.lead(), variant: "lime" }}
      />

      {/* Verhuisd van de homepage */}
      <Statement
        bg="W"
        id="mythe"
        eyebrow={MYTH.eyebrow}
        text={MYTH.quote}
        heading={MYTH.heading}
        highlight={["gasketel.”"]}
        pills={MYTH.pills.map((label) => ({ label }))}
        scrub
      />

      <DataBand
        id="cijfers"
        intro={{ eyebrow: DATA.eyebrow, title: DATA.title, titleMuted: DATA.titleMuted, lead: DATA.lead }}
        mode="chart"
        chart={{
          type: "bar",
          title: "Kost per kWh nuttige warmte (indicatief)",
          props: {
            bars: [
              { label: "Gasketel", value: "warmtekostGasPerKwhWarmte", display: `${v("warmtekostGasPerKwhWarmte", { scale: 100, dec: 1 })} c/kWh`, series: "base" },
              { label: "Warmtepomp op netstroom", value: "warmtekostWarmtepompPerKwhWarmte", display: `${v("warmtekostWarmtepompPerKwhWarmte", { scale: 100, dec: 1 })} c/kWh`, series: "good" },
            ],
            caption: "Met eigen zonnestroom, die je anders voor enkele centen zou injecteren, wordt warmte uit een warmtepomp nog veel goedkoper.",
          },
        }}
        stats={[
          { k: "breakEvenScop", label: "SCOP waarboven een warmtepomp goedkoper is dan gas" },
          { k: "voorbeeldBesparingWarmtepomp", label: "Besparing per jaar in ons rekenvoorbeeld (zonder zonnepanelen)", prefix: "€ " },
          { k: "btwWarmtepomp", label: "Btw op een warmtepomp tegenover een nieuwe gasketel", display: `${v("btwWarmtepomp")}% vs ${v("btwGasketel")}%` },
        ]}
        urgency={[
          { k: "ets2Start", label: "Europese CO₂-prijs op gas (ETS2) vanaf" },
          { k: "verbodGasNieuwbouw", label: "Geen gasaansluiting meer bij nieuwbouw sinds" },
        ]}
        assumptions={["gasprijsAllIn", "stroomprijsAllIn", "rendementGascondensatieketel", "scopRekenwaarde", "warmtekostGasPerKwhWarmte", "warmtekostWarmtepompPerKwhWarmte", "breakEvenScop", "voorbeeldBesparingWarmtepomp", "btwWarmtepomp", "btwGasketel"]}
        assumptionsNote="Kost per kWh warmte = energieprijs gedeeld door het rendement: gas met een condensatieketel, stroom met de SCOP van een goed ontworpen warmtepomp. Vlakke prijzen, gemiddeld contract."
        cta={{ label: "Bereken wat jouw woning kan besparen", href: routes.lead(), variant: "lime" }}
        image={{ src: "/images/vbtec/warmtepomp-buitenunit.jpg", alt: "Buitenunit van een warmtepomp naast een woning", width: 1253, height: 834 }}
      />

      <LeadSection bron={routes.vergelijken()} heading="Twijfel je nog? Vraag je offerte aan, met jouw scenario's naast elkaar." />

      <LatestPosts />

      <Faq title="Vragen over onze vergelijkingen" items={FAQ} />

      <JsonLd data={itemList(comparisons.map((c) => ({ name: c.shortTitle, path: routes.comparison(c.slug) })))} />
    </>
  );
}
