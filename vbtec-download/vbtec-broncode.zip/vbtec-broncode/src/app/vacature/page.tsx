import DkPage, { dkMetadata } from "@/components/dagklok/DkPage";

export const metadata = dkMetadata("vacature");

export default function Page() {
  return <DkPage slug={"vacature"} />;
}
