import ProductsSection from "@/components/products/ProductsSection";
import DagklokLoader from "@/components/dagklok/DagklokLoader";
import DkHero from "@/components/dagklok/sections/DkHero";
import DkRest from "@/components/dagklok/sections/DkRest";
import DkOffer from "@/components/dagklok/sections/DkOffer";
import Calculator from "@/components/dagklok/Calculator";
import HomeMore from "@/components/dagklok/HomeMore";
import "@/components/dagklok/dagklok.css";
import { JsonLd } from "@/components/ui";
import { buildMetadata } from "@/lib/seo";
import { localBusiness } from "@/lib/schema";

// Homepage = Luka's Dagklok page (short, for sales) under Levi's menu and footer:
// slogan hero · product strip · the day clock (house from dawn to night, live energy map) ·
// four parts, one system · business scale · offer form.
// All of Levi's former homepage copy now lives on the sub pages (diensten, projecten,
// hoe-het-werkt, hoe-we-werken, over-ons, vergelijken), so it stays indexable.
export const metadata = buildMetadata({
  title: "VB-TEC | Zonnepanelen, thuisbatterij, laadpaal en warmtepomp in West-Vlaanderen",
  absoluteTitle: true,
  description:
    "Your energy, our power. VB-TEC uit Pittem plaatst zonnepanelen, thuisbatterijen, laadpalen en warmtepompen voor thuis en bedrijven. Eén installateur, van dak tot meterkast. Offerte binnen de 4 werkdagen.",
  path: "/",
});

export default function Home() {
  return (
    <div id="dk-root">
      <div className="dk" data-header-tone="dark">
        <DkHero />
      </div>
      <ProductsSection />
      <div className="dk">
        <DkRest />
      </div>
      <Calculator />
      <div className="dk">
        <DkOffer />
      </div>
      <HomeMore />
      <DagklokLoader rootId="dk-root" />
      <JsonLd data={localBusiness()} />
    </div>
  );
}
