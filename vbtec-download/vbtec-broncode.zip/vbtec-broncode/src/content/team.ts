// PLACEHOLDER – vervang door echte gegevens
// Voorbeeldteam: verzonnen namen, rollen en aantallen. Geen echte medewerkers.
// Zolang `isPlaceholder` true is: geen Person-schema (00 §2.8), silhouetten i.p.v. foto's
// (geen AI-gezichten), en blog/kennisbank-artikels krijgen de Organization als auteur in JSON-LD.
// Volgorde = ingenieurs eerst (zij rekenen), daarna installateurs en kantoor.

import type { TeamMember } from "./types";

export const isPlaceholder = false;
export const PLACEHOLDER_LABEL = "Voorbeeldteam";

export type TeamGroup = "ingenieurs" | "installatie" | "kantoor";

export type TeamMemberContent = TeamMember & {
  group: TeamGroup;
  /** Short "what I do at your home" line, shown on /team. */
  atYourHome: string;
};

export const TEAM_GROUPS: { key: TeamGroup; title: string; intro: string }[] = [
  {
    key: "ingenieurs",
    title: "De ingenieurs die rekenen",
    intro: "Zij bekijken je verbruik, je dak en je woning, en rekenen de scenario's uit. Geen verkoopdoelen, wel een rekenblad.",
  },
  {
    key: "installatie",
    title: "De vakmensen die plaatsen",
    intro: "Eigen ploegen die installeren wat de ingenieur berekende, en het netjes opleveren met keuring en uitleg.",
  },
  {
    key: "kantoor",
    title: "Wie alles in goede banen leidt",
    intro: "Planning, premies en opvolging: zodat jij niet achter papierwerk hoeft te lopen.",
  },
];

// VB-TEC: geen voorbeeld-team meer online. Vul hier enkel echte gegevens in (met toestemming).
export const team: TeamMemberContent[] = [];

export function getTeamMember(slug: string): TeamMemberContent | undefined {
  return team.find((m) => m.slug === slug);
}

export function getTeamByGroup(group: TeamGroup): TeamMemberContent[] {
  return team.filter((m) => m.group === group);
}

export const engineers = getTeamByGroup("ingenieurs");
