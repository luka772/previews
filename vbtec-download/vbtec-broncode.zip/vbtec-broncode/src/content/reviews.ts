// PLACEHOLDER – vervang door echte gegevens
// Voorbeeldreviews: verzonnen, niet van echte klanten. Zolang `isPlaceholder` true is:
// geen score, geen platformnaam, geen Review/AggregateRating-schema (00 §2.8–2.9),
// en de UI toont het label "Voorbeeldreviews".

import type { Review } from "./types";
import type { ServiceSlug } from "./registry";

export const isPlaceholder = false;
export const PLACEHOLDER_LABEL = "Voorbeeldreviews";

/** Only filled in once reviews are real and first-party (then shown in ReviewWall summary). */
export const reviewSummary: { score: string; count: string; source: string } | null = null;

// VB-TEC: geen voorbeeld-reviews meer online. Vul hier enkel echte gegevens in (met toestemming).
export const reviews: Review[] = [];

/** Reviews mentioning a product; falls back to all reviews when fewer than `min` match. */
export function getReviewsByProduct(slug: ServiceSlug, min = 3): Review[] {
  const matches = reviews.filter((r) => r.products.includes(slug));
  return matches.length >= min ? matches : [...matches, ...reviews.filter((r) => !r.products.includes(slug))];
}
