// PLACEHOLDER – vervang door echte gegevens
// Company data (NAP, metrics, promises) + navigation (00 §2.1: replaces company.ts + navigation.ts).
// While `isPlaceholder` is true, structured data never emits telephone/e-mail/address/opening hours
// (00 §2.8) and the UI shows these values only as contact details, never as verified claims.

import {
  ARTICLES,
  COMPARISONS,
  PAGES,
  SERVICE_GROUPS,
  SERVICE_TAGLINES,
  SERVICES,
} from "./registry";
import { routes } from "@/lib/routes";

export const site = {
  isPlaceholder: false,
  name: "VB-TEC",
  legalName: "VB-TEC BV",
  tagline: "Energie-ingenieurs voor jouw woning",
  promise: "Ingenieurs die rekenen, geen verkopers die duwen.",
  description:
    "VB-TEC rekent als ingenieur uit welke combinatie van zonnepanelen, PVT, warmtepomp, thuisbatterij en laadpaal jouw energiefactuur zo dicht mogelijk bij €0 brengt. Eerlijk, ook als het niet loont.",
  phone: "051 15 31 15",
  salesPhone: "051 15 31 12",
  salesPhoneHref: "tel:+3251153112",
  phoneHref: "tel:+3251153115",
  email: "info@vbtec.be",
  address: {
    street: "Brugsesteenweg 81",
    postalCode: "8740",
    city: "Pittem",
    country: "BE",
  },
  vat: "BE 0730.762.663",
  areaServed: "Vlaanderen",
  areaLabel: "Vanuit Pittem, actief in Vlaanderen",
  // TODO: echte openingsuren van VB-TEC invullen (leeg = niet getoond).
  openingHours: [] as { days: string; hours: string }[],
  /** schema.org openingHours strings – only emitted when isPlaceholder === false. */
  openingHoursSpec: [] as string[], // TODO: echte openingsuren
  responseTime: "2 werkdagen", // PLACEHOLDER (00 §2.5)
  /** Only show the planning line (03 §5) when the client fills this in. */
  leadTimeWeeks: undefined as number | undefined,
  /** "In {x}% van de berekeningen raadden we minstens één product af." */
  adviceAgainstPct: 38, // PLACEHOLDER
  calculationsCount: 1200, // PLACEHOLDER
  /** Google review badge in image heroes. PLACEHOLDER – vervang door de echte Google-score. */
  googleRating: { score: "4,9", count: 127 },
  guarantees: [
    "Geen voorschot vóór je akkoord", // PLACEHOLDER – bevestigen met klant
    "Fabrieksgarantie + installatiegarantie (termijnen volgen)", // PLACEHOLDER
    "Wij vragen je premies aan",
  ],
  /** Text-only quality labels (no third-party logos). */
  trustLabels: [] as string[], // TODO: enkel echte erkenningen/labels
  socialProfiles: ["https://www.facebook.com/profile.php?id=100057225408730", "https://www.instagram.com/vbtec_bv/", "https://www.linkedin.com/company/vb-tec/"] as string[],
  /** Echte cijfers van vbtec.be. */
  realCounts: { zonnepanelen: 25272, warmtepompen: 250, laadpalen: 150 },
  foundingYear: "2026", // PLACEHOLDER
  /** Static footer year (no Date.now() in render). */
  copyrightYear: "2026",
} as const;

export const TRUSTLINE = [
  "Gratis en vrijblijvend",
  "Berekend door een ingenieur",
  "Eerlijk, ook als het niet loont",
] as const;

// ───────────────────────── Navigation ─────────────────────────
export type NavLink = { label: string; href: string; description?: string };
/** A menu column. With `block`, it renders as a large card (photo, title, intro, link). */
export type NavColumn = { title: string; links: NavLink[]; block?: { href: string; intro: string; image: string; cta: string } };
export type NavItem =
  | { kind: "link"; label: string; href: string }
  | {
      kind: "menu";
      label: string;
      /** Path prefix that marks this item active. */
      match: string[];
      columns: NavColumn[];
      feature?: { title: string; body: string; href: string; cta: string };
      footerLink?: NavLink;
    };

const serviceColumns: NavColumn[] = SERVICE_GROUPS.map((g) => ({
  title: g.title,
  links: SERVICES.filter((s) => s.group === g.key).map((s) => ({
    label: s.shortTitle,
    href: routes.service(s.slug),
    description: SERVICE_TAGLINES[s.slug],
  })),
}));

export const navigation: { main: NavItem[]; cta: { label: string; shortLabel: string; href: string } } = {
  main: [
    {
      kind: "menu",
      label: "Oplossingen",
      match: ["/diensten", "/bedrijven"],
      columns: [
        {
          title: "Particulier",
          block: { href: routes.diensten(), intro: "Voor je woning: van het dak tot in je auto.", image: "/images/dagklok/hero-huis.webp", cta: "Alles voor thuis" },
          links: [
            { label: "Zonnepanelen", href: routes.service("zonnepanelen") },
            { label: "Thuisbatterij", href: routes.service("thuisbatterij") },
            { label: "Laadpaal", href: routes.service("laadpalen") },
            { label: "Warmtepomp (lucht-water)", href: routes.service("lucht-water-warmtepomp") },
            { label: "Airco (lucht-lucht)", href: routes.service("lucht-lucht-warmtepomp") },
            { label: "PVT-panelen", href: routes.service("pvt-panelen") },
            { label: "Omvormers", href: routes.service("omvormers") },
          ],
        },
        {
          title: "Professioneel",
          block: { href: "/bedrijven", intro: "Voor je bedrijf: grote daken, eigen opslag en een vloot die slim laadt.", image: "/dagklok/img/bedrijf-dak.webp", cta: "Alles voor bedrijven" },
          links: [
            { label: "Zonnepanelen voor bedrijven", href: "/bedrijven/zonnepanelen" },
            { label: "Batterijopslag", href: "/bedrijven/batterijopslag" },
            { label: "Laadinfrastructuur", href: "/bedrijven/laadinfrastructuur" },
            { label: "Oplossing op maat", href: "/bedrijven/op-maat" },
            { label: "Projecten voor bedrijven", href: "/bedrijven/projecten" },
            { label: "Merken & partners", href: "/bedrijven/partners" },
          ],
        },
      ],
    },
    { kind: "link", label: "Projecten", href: routes.projecten() },
    {
      kind: "menu",
      label: "Kennis",
      match: ["/hoe-het-werkt", "/vergelijken", "/kennisbank", "/blog"],
      columns: [
        {
          title: "Uitgelegd",
          links: [
            { label: "Hoe het werkt", href: routes.hoeHetWerkt(), description: "Zon, warmte, opslag en laden als één systeem" },
            { label: "Kennisbank", href: routes.kennisbank(), description: "Elk begrip uitgelegd, met bron en datum" },
            { label: "Blog", href: routes.blog(), description: "Wat verandert er, en wat betekent het voor jou?" },
          ],
        },
        {
          title: "Vergelijken",
          links: COMPARISONS.map((c) => ({ label: c.shortTitle, href: routes.comparison(c.slug) })),
        },
      ],
      footerLink: { label: "Alle vergelijkingen", href: routes.vergelijken() },
    },
    {
      kind: "menu",
      label: "Over ons",
      match: ["/over-ons", "/hoe-we-werken", "/team"],
      columns: [
        {
          title: "VB-TEC",
          links: [
            { label: "Over ons", href: routes.overOns(), description: "Waarom ingenieurs rekenen, niet verkopen" },
            { label: "Hoe we werken", href: routes.hoeWeWerken(), description: "Van offerte tot opvolging" },
          ],
        },
      ],
    },
  ],
  cta: { label: "Offerte aanvragen", shortLabel: "Offerte", href: routes.lead() },
};

export const footerColumns: NavColumn[] = [
  {
    title: "Diensten",
    links: SERVICES.map((s) => ({ label: s.shortTitle, href: routes.service(s.slug) })),
  },
  {
    title: "Vergelijken",
    links: COMPARISONS.map((c) => ({ label: c.shortTitle, href: routes.comparison(c.slug) })),
  },
  {
    title: "Kennis",
    links: [
      { label: PAGES.hoeHetWerkt.shortTitle, href: routes.hoeHetWerkt() },
      { label: PAGES.kennisbank.shortTitle, href: routes.kennisbank() },
      { label: PAGES.blog.shortTitle, href: routes.blog() },
      { label: PAGES.projecten.shortTitle, href: routes.projecten() },
    ],
  },
  {
    title: "Bedrijf",
    links: [
      { label: PAGES.overOns.shortTitle, href: routes.overOns() },
      { label: PAGES.hoeWeWerken.shortTitle, href: routes.hoeWeWerken() },
      { label: PAGES.contact.shortTitle, href: routes.contact() },
    ],
  },
];

/** Kept for completeness (kennisbank article count in nav copy etc.). */
export const kennisbankCount = ARTICLES.length;
